#!/usr/bin/env python

from brain_games.games import even


def main():
    print('Welcome to the Brain Games!')
    even.even_game()


if __name__ == '__main__':
    main()
